# IslamAI
Islam AI for Microsoft Imagine Cup
# How to run
1.Install flask   
2.Run main.py
# IN-DEVELOPMENT
1.Query display   
2.Natural Language Processor
